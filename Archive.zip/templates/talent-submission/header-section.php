<?php
/**
 * Header Section Template Part
 * 
 * Displays logo and theme switcher
 * 
 * @package HelloElementorChild
 */

// Get WordPress custom logo
$custom_logo_id = get_theme_mod('custom_logo');
?>

<div class="logo">
    <a href="<?php echo esc_url(home_url('/')); ?>">
        <?php if ($custom_logo_id) : ?>
            <?php
            $logo_html = wp_get_attachment_image($custom_logo_id, 'full', false, array(
                'alt' => get_bloginfo('name'),
                'class' => 'custom-logo'
            ));
            if ($logo_html) {
                echo $logo_html;
            } else {
                echo '<span class="site-name">' . esc_html(get_bloginfo('name')) . '</span>';
            }
            ?>
        <?php else : ?>
            <span class="site-name"><?php echo esc_html(get_bloginfo('name')); ?></span>
        <?php endif; ?>
    </a>

    <div class="theme-switcher">
        <div class="theme-toggle" id="themeToggle">
            <svg class="sun-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="5"></circle>
                <line x1="12" y1="1" x2="12" y2="3"></line>
                <line x1="12" y1="21" x2="12" y2="23"></line>
                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                <line x1="1" y1="12" x2="3" y2="12"></line>
                <line x1="21" y1="12" x2="23" y2="12"></line>
                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
            </svg>
            <svg class="moon-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
            </svg>
        </div>
    </div>
</div>
